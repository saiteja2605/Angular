import { Component } from '@angular/core';
import { EmployeesListService } from './employees-list-page/employees-list-page.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Employee_Management';
}
