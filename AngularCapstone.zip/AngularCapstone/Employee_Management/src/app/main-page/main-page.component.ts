import { Component } from '@angular/core';

@Component({
  selector: 'app-main-page',
  template: '',
})
export class MainPageComponent {

}
